import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { MovieService, Movie } from '../../services/movie';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-movie',
  standalone: true,
  templateUrl: './movie.html',
  styleUrls: ['./movie.css'],
  imports: [CommonModule]
})
export class MovieComponent implements OnInit {
  filme: Movie | null = null;

  constructor(
    private route: ActivatedRoute,
    private movieService: MovieService
  ) {}

  ngOnInit(): void {
    this.route.paramMap.subscribe((params) => {
      const idParam = params.get('id');
      const id = Number(idParam);

      if (!isNaN(id)) {
        this.movieService.getFilmeById(id).subscribe({
          next: (filme) => this.filme = filme,
          error: (err) => {
            console.error('Erro ao carregar o filme:', err);
            this.filme = null;
          }
        });
      } else {
        console.error('ID inválido na rota:', idParam);
        this.filme = null;
      }
    });
  }



}
